package com.example.employee_managment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
