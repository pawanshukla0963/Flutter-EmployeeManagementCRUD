import 'package:flutter/material.dart';

const kPrimaryLightColor = Color(0xffffffff);
const kPrimaryBlackColor = Color(0xff000000);
const kSubBlackColor = Color(0xff616161);
const kDividerColor = Color(0xffFAFAFA);

const kSecondaryColor = Color(0xFFFE4350);
const kIconColor = Color(0xff666666);
const kbgColor = Color(0xFFFAFAFA);
