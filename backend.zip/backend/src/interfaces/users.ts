export default interface IUser {
    id: number;
    email: string;
	full_name: string;
	phone_number: string
    password: string;
	user_type: string;
}
